package algstudent.s3;

import java.util.Arrays;

public class Mergesort {

	public static void main(String[] args) {
		int[] vector = new int[16000000];
		Vector.randomSorted(vector);
		
//		for (int i : vector)
//			System.out.print(i + ",");
//		
//		System.out.println();
//		
		long t1 = System.currentTimeMillis();
		mergesort(vector);
		long t2 = System.currentTimeMillis();
//		
		System.out.println(t2 - t1);
//		
//		for (int i : vector)
//			System.out.print(i + ",");
	}

	public static void mergesort(int v[]) {
		if (v.length != 1) {
			int middle = (v.length) / 2;
			int[] left = Arrays.copyOfRange(v, 0, middle);
			int[] right = Arrays.copyOfRange(v, middle, v.length);
			mergesort(left);
			mergesort(right);
			int i = 0;
			int j = 0;
			for (int k = 0; k < v.length; k++) {
				if (i < left.length && j < left.length) {
					if (left[i] < right[j]) {
						v[k] = left[i];
						i++;
					} else {
						v[k] = right[j];
						j++;
					}
				} else if (i < left.length) {
					v[k] = left[i];
					i++;
				} else {
					v[k] = right[j];
					j++;
				}
			}
		}
	}

	public static int[] split(int from, int to, int[] v) {
		int[] ret = new int[to - from + 1];
		for (int i = from; i <= to; i++)
			ret[i - from] = v[i];
		return ret;
	}
}
