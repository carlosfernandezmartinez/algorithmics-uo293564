import java.util.ArrayList;

public class A4 {

	public static void main(String args[]) {
		System.out.println(isPrime(15));
		System.out.println(isPrime(21));
		System.out.println(isPrime(29));
		System.out.println(isPrime(2));
		System.out.println(isPrime(4));

		
		int n = 10000;
		for (int i = 0; i < 7; i++) {
			long t1 = System.currentTimeMillis();
			ArrayList<Integer> primes = new ArrayList<Integer>();
			for (int j = 2; j < n+1; j++) {
				if (isPrime(j))
					primes.add(j);
			}
			long t2 = System.currentTimeMillis();
			System.out.println("Time for n = " + n + ": " + (t2 - t1) + " ms");
			n *= 2;
		}
	}

	private static boolean isPrime(int j) {
		if (j == 2)
			return true;
		
		for (int i = 2; i < (Math.sqrt(j) + 1); i++) {
			if (j%i == 0)
				return false;
		}
		return true;
	}
	
}
