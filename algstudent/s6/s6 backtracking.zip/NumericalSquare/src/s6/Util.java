package s6;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class Util {
	
	public static final int SUM = -130;
	public static final int MINUS = -131;
	public static final int MULT = -132;
	public static final int DIV = -133;
	public static final int EMPTY = -134;
	public static final int EQUAL = -135;
	public static final int REEMP = -136;
	
	public static int[][] readMatrixFrom(String filename) {
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filename)));
			int size = Integer.parseInt(br.readLine());
			String[][] ret = new String[size * 2 + 1][size * 2 + 1];
			for (int i = 0; i < ret.length; i++) {
				String line = br.readLine();
				if (i % 2 == 0 && i != ret.length - 1) {
					ret[i] = line.split(" ");
				} else {
					for (int j = 0; j < line.split(" ").length; j++) {
						ret[i][j*2] = line.split(" ")[j];
					}
				}
			}
			for (int i = 0; i < ret.length; i++) {
				for (int j = 0; j < ret.length; j++) {
					if (ret[i][j] == null) {
						ret[i][j] = "";
					}
				}
			}
			br.close();
			return toConst(ret);
		} catch (IOException e) {
			throw new IllegalArgumentException("Invalid file");
		}
	}
	
	private static int[][] toConst(String[][] matrix) {
		int[][] ret = new int[matrix.length][matrix.length];
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++ ) {
				switch(matrix[i][j]) {
				case "?":
					ret[i][j] = REEMP;
					break;
				case "+":
					ret[i][j] = SUM;
					break;
				case "-":
					ret[i][j] = MINUS;
					break;
				case "*":
					ret[i][j] = MULT;
					break;
				case "/":
					ret[i][j] = DIV;
					break;
				case "":
					ret[i][j] = EMPTY;
					break;
				case "=":
					ret[i][j] = EQUAL;
					break;
				default:
					ret[i][j] = Integer.parseInt(matrix[i][j]);
					break;
				}
			}
		}
		return ret;
	}

	public static boolean[][] getModifiablesIn(int[][] matrix) {
		boolean[][] modifiables = new boolean[matrix.length][matrix.length];
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				if (matrix[i][j] == REEMP) {
					modifiables[i][j] = true;
				}
			}
		}
		return modifiables;
	}
}
