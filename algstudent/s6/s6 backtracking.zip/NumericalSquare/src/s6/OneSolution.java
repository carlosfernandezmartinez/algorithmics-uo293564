package s6;

public class OneSolution {

	public static void main(String[] args) {
		NumericalSquareOne ns = new NumericalSquareOne("test07.txt");
		NumericalSquareOne.printMatrix(ns.matrix);
		long t1 = System.currentTimeMillis();
		ns.solve();
		long t2 = System.currentTimeMillis();
		System.out.println("First solution found after " + (t2 - t1) + " ms");
	}

}
