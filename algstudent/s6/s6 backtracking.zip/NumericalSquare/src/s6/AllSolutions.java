package s6;

public class AllSolutions {

	public static void main(String[] args) {
		NumericalSquareAll ns = new NumericalSquareAll("test06.txt");
		NumericalSquareAll.printMatrix(ns.matrix);
		long t1 = System.currentTimeMillis();
		ns.solve();
		long t2 = System.currentTimeMillis();
		System.out.println("All " + ns.numberOfSolutions + " solutions found after " + (t2 - t1) + " ms");
	}

}
