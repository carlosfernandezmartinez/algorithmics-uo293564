package s6;

public class NumericalSquareAll {

	int[][] solution;
	int[][] matrix;
	int size;
	boolean[][] isModifiable;
	int numberOfSolutions;

	public NumericalSquareAll(String filename) {
		matrix = Util.readMatrixFrom(filename);
		isModifiable = Util.getModifiablesIn(matrix);
		solution = new int[matrix.length][matrix.length];
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				solution[i][j] = matrix[i][j];
			}
		}
		size = (matrix.length - 1) / 2;
	}

	public void solve() {
		backtracking(0);
	}

	private void backtracking(int position) {
		int i = (position / size) * 2;
		int j = (position % size) * 2;
		// try all digits in that position
		for (int digit = 0; digit < 10; digit++) {
			// if modifiable try a digit in there
			if (isModifiable[i][j]) {
				solution[i][j] = digit;
			}
			// last position ?
			if (i == solution.length - 3 && j == solution.length - 3) {
				// If that row and that column are valid -> solution found
				if (checkRow(i) && checkColumn(j)) {
					numberOfSolutions++;
					System.out.println("SOLUTION " + numberOfSolutions + " FOUND");
					printMatrix(solution);
				}
				// last column ?
			} else if (j == solution.length - 3) {
				// is that row right ? continue backtracking : prune that branch
				if (checkRow(i)) {
					backtracking(position + 1);
				}
				// last row ?
			} else if (i == solution.length - 3) {
				// is that column right ? continue backtracking : prune that branch
				if (checkColumn(j)) {
					backtracking(position + 1);
				}
				// not last row nor column -> continue backtracking
			} else {
				backtracking(position + 1);
			}
			// if it was not modifiable do not iterate more than once
			if (!isModifiable[i][j]) {
				break;
			}
		}
	}

	public boolean checkRow(int index) {
		int result = solution[index][0];
		for (int i = 1; i < solution.length - 3; i += 2) {
			if (solution[index][i - 1] == Util.REEMP || solution[index][i + 1] == Util.REEMP)
				return false;
			switch (solution[index][i]) {
			case Util.SUM:
				result += solution[index][i + 1];
				break;
			case Util.MINUS:
				result -= solution[index][i + 1];
				break;
			case Util.MULT:
				result *= solution[index][i + 1];
				break;
			case Util.DIV:
				if (solution[index][i + 1] == 0)
					return false;
				if (result % solution[index][i + 1] != 0)
					return false;
				result /= solution[index][i + 1];
				break;
			}
		}
		return solution[index][solution[index].length - 1] == result;
	}

	public boolean checkColumn(int index) {
		int result = solution[0][index];
		for (int i = 1; i < solution.length - 3; i += 2) {
			if (solution[i - 1][index] == Util.REEMP || solution[i + 1][index] == Util.REEMP)
				return false;
			switch (solution[i][index]) {
			case Util.SUM:
				result += solution[i + 1][index];
				break;
			case Util.MINUS:
				result -= solution[i + 1][index];
				break;
			case Util.MULT:
				result *= solution[i + 1][index];
				break;
			case Util.DIV:
				if (solution[i + 1][index] == 0)
					return false;
				else if (result % solution[i + 1][index] != 0)
					return false;
				result /= solution[i + 1][index];
				break;
			}
		}
		return solution[solution.length - 1][index] == result;
	}

	public static void printMatrix(int[][] matrix) {
		for (int i = 0; i < matrix.length; i++)
			System.out.print("--------");
		System.out.println();
		for (int[] row : matrix) {
			for (int elem : row) {
				switch (elem) {
				case Util.EMPTY:
					System.out.print("\t");
					break;
				case Util.REEMP:
					System.out.print("?" + "\t");
					break;
				case Util.SUM:
					System.out.print("+" + "\t");
					break;
				case Util.MINUS:
					System.out.print("-" + "\t");
					break;
				case Util.MULT:
					System.out.print("*" + "\t");
					break;
				case Util.DIV:
					System.out.print("/" + "\t");
					break;
				case Util.EQUAL:
					System.out.print("=" + "\t");
					break;
				default:
					System.out.print(elem + "\t");
					break;
				}
			}
			System.out.println("\n");
		}
		for (int i = 0; i < matrix.length; i++)
			System.out.print("--------");
		System.out.println();
	}
}
