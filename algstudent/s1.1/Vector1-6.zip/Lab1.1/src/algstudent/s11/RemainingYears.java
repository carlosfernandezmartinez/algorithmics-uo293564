package algstudent.s11;

import java.text.SimpleDateFormat;
import java.util.Date;

public class RemainingYears {

	public static void main(String args[]) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy");

		System.out.println("We can use currentTimeMillis for "
				+ (Long.parseLong(df.format(new Date(Long.MAX_VALUE))) - Long.parseLong(df.format(new Date())))
				+ " more years");
	}
}
