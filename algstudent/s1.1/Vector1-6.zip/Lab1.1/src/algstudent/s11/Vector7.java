package algstudent.s11;

public class Vector7 {

	public static void main(String args[]) {
		for (int i = 10000; i < 81920001; i *= 2) {
			int[] v = new int[i];
			Vector1.fillIn(v);
			long t1 = System.currentTimeMillis();
			Vector1.matches2(v, v);
			long t2 = System.currentTimeMillis();
			System.out.println("Matches2 with n: " + i + " - " + (t2 - t1));
		}
	}
}
