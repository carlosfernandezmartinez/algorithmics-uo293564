package algstudent.s11;

public class Vector6 {

	public static void main(String args[]) {
		int repetitions = Integer.parseInt(args[0]);

		for (int i = 10000; i < 81920001; i *= 2) {
			int[] v = new int[i];
			Vector1.fillIn(v);
			long t1 = System.currentTimeMillis();
			for (int j = 0; j < repetitions; j++)
				Vector1.matches1(v, v);
			long t2 = System.currentTimeMillis();
			System.out.println("Matches1 with n: " + i + " - " + (t2 - t1));
		}
	}
}
